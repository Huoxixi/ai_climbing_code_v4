// Executed only inside the isolated imported document, before its own scripts.
export function readerBootstrap(config){
 const send=(type,payload={})=>parent.postMessage({studyReader:config.nonce,type,...payload},'*');
 function storage(initial,persistent){let cache=Object.assign(Object.create(null),initial);const check=()=>{if(Object.keys(cache).length>200||new TextEncoder().encode(JSON.stringify(cache)).length>2*1024*1024)throw new DOMException('学习记录空间已满','QuotaExceededError');};const notify=()=>{if(persistent)send('storage',{storage:cache});};const methods={getItem:key=>Object.hasOwn(cache,String(key))?cache[String(key)]:null,setItem:(key,value)=>{key=String(key);value=String(value);if(key.length>200)throw new DOMException('记录名称过长','QuotaExceededError');const old=cache[key],existed=Object.hasOwn(cache,key);cache[key]=value;try{check();}catch(e){if(existed)cache[key]=old;else delete cache[key];throw e;}notify();},removeItem:key=>{delete cache[String(key)];notify();},clear:()=>{cache=Object.create(null);notify();},key:index=>Object.keys(cache)[Number(index)]??null};return new Proxy(methods,{get:(t,k)=>k==='length'?Object.keys(cache).length:Reflect.has(t,k)?Reflect.get(t,k):cache[k],set:(t,k,v)=>{methods.setItem(k,v);return true;},deleteProperty:(t,k)=>{methods.removeItem(k);return true;},ownKeys:()=>Object.keys(cache),getOwnPropertyDescriptor:(t,k)=>Object.hasOwn(cache,k)?{configurable:true,enumerable:true,value:cache[k],writable:true}:undefined});}
 Object.defineProperty(window,'localStorage',{value:storage(config.storage,true),configurable:false});
 Object.defineProperty(window,'sessionStorage',{value:storage({},false),configurable:false});
 function routeAnchor(a){const raw=a.getAttribute('href')||'';if(raw.startsWith('#'))return false;
  if(raw.startsWith('blob:')||raw.startsWith('data:')){(async()=>{try{const blob=await(await fetch(raw)).blob();if(blob.size>20*1024*1024){send('warning',{message:'导出的文件超过20MB，请分开备份。'});return;}send('download',{bytes:await blob.arrayBuffer(),filename:a.download||'学习备份.json',mime:blob.type||'application/octet-stream'});}catch{send('warning',{message:'无法读取这个导出文件，可以使用资料库的备份入口。'});}})();return true;}
  try{const url=new URL(raw);if(['https:','http:'].includes(url.protocol))send('external',{url:url.href});else send('warning',{message:'这个链接无法在资料库中打开。'});}catch{send('warning',{message:'这份HTML引用了旁边的文件，单独导入时没有包含它。'});}return true;
 }
 const originalAnchorClick=HTMLAnchorElement.prototype.click;
 HTMLAnchorElement.prototype.click=function(){if(!routeAnchor(this))return originalAnchorClick.call(this);};
 document.addEventListener('click',e=>{const a=e.target.closest?.('a');if(a&&routeAnchor(a)){e.preventDefault();e.stopImmediatePropagation();}},true);
 window.addEventListener('error',()=>send('warning',{message:'这份HTML有脚本未能运行。如果交互异常，请使用包含全部脚本的独立HTML。'}));
 send('ready');
}

export function buildReaderHTML(raw,config){
 const doc=new DOMParser().parseFromString(raw,'text/html');
 doc.querySelectorAll('base,meta[http-equiv="refresh" i],iframe,object,embed').forEach(n=>n.remove());
 const meta=doc.createElement('meta');meta.httpEquiv='Content-Security-Policy';meta.content="default-src 'none'; script-src 'unsafe-inline' 'unsafe-eval' blob:; style-src 'unsafe-inline' data:; img-src data: blob:; font-src data:; media-src data: blob:; connect-src blob: data:; frame-src 'none'; object-src 'none'; base-uri 'none'; form-action 'none'";
 const script=doc.createElement('script');script.textContent='('+readerBootstrap.toString()+')('+JSON.stringify(config).replace(/</g,'\\u003c')+');';
 doc.head.prepend(meta,script);return '<!doctype html>\n'+doc.documentElement.outerHTML;
}

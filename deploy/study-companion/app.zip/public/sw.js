// Private API responses and imported documents are never added to this cache.
const CACHE='study-shell-v2',ASSETS=['/study/style.css','/study/app.js','/study/reader-bridge.js','/study/ui.js','/study/ui.css','/study/surface.css','/study/icon.svg'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS)).then(()=>self.skipWaiting()));});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('study-shell-')&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));});
self.addEventListener('fetch',e=>{if(e.request.method!=='GET'||!ASSETS.includes(new URL(e.request.url).pathname))return;e.respondWith(fetch(e.request).catch(()=>caches.match(e.request)));});
